# Compress PDF — Client-Side

Website khusus compress PDF dengan hasil kualitas sebaik mungkin di browser.

## Fitur

- 3 preset kualitas: Tinggi / Sedang / Rendah
- Pengaturan lanjutan (scale render + kualitas JPEG)
- Progress bar real-time per halaman
- Perbandingan ukuran sebelum & sesudah
- 100% privat (tidak ada upload ke server)

## Cara Pakai

1. Buka `index.html` di Chrome / Firefox / Edge / Safari
2. Atau upload ke Vercel / Netlify / Cloudflare Pages

## Catatan Kualitas

Metode yang dipakai: render setiap halaman PDF dengan PDF.js (skala tinggi) → encode ulang sebagai JPEG berkualitas → susun kembali menjadi PDF baru.

- Mode **Tinggi** (default): scale 2.0x + JPEG 88% → hasil paling tajam
- Mode **Sedang**: scale 1.6x + JPEG 72%
- Mode **Rendah**: scale 1.25x + JPEG 55% → ukuran paling kecil

Teks akan menjadi gambar (tidak bisa di-select/copy). Ini trade-off normal untuk compress agresif di browser.
